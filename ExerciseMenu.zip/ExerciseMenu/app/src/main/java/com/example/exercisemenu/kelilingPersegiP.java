package com.example.exercisemenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class kelilingPersegiP extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keliling_persegi_p);
    }
}
